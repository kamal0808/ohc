$(function(){
    $(".instructions").click(function(){
        $(".instructions-area").toggle();
    })
})